IF DB_ID('EmployeeDB') IS NULL BEGIN CREATE DATABASE EmployeeDB; END
GO
USE EmployeeDB;
GO
IF OBJECT_ID('dbo.Employees','U') IS NOT NULL DROP TABLE dbo.Employees;
IF OBJECT_ID('dbo.Departments','U') IS NOT NULL DROP TABLE dbo.Departments;
IF OBJECT_ID('dbo.Admins','U') IS NOT NULL DROP TABLE dbo.Admins;
GO
CREATE TABLE dbo.Departments(DepartmentId INT IDENTITY(1,1) PRIMARY KEY, DepartmentName NVARCHAR(100) NOT NULL);
CREATE TABLE dbo.Admins(AdminId INT IDENTITY(1,1) PRIMARY KEY, Username NVARCHAR(100) UNIQUE NOT NULL, [Password] NVARCHAR(100) NOT NULL);
CREATE TABLE dbo.Employees(
 EmployeeId INT IDENTITY(1,1) PRIMARY KEY,
 FullName NVARCHAR(100) NOT NULL,
 Email NVARCHAR(100) UNIQUE NOT NULL,
 [Password] NVARCHAR(100) NOT NULL,
 DepartmentId INT NOT NULL,
 Role NVARCHAR(50),
 Salary DECIMAL(18,2) DEFAULT 0,
 HireDate DATE DEFAULT GETDATE(),
 CONSTRAINT FK_Employees_Departments FOREIGN KEY(DepartmentId) REFERENCES dbo.Departments(DepartmentId)
);
INSERT INTO dbo.Departments(DepartmentName) VALUES ('HR'),('Engineering'),('Sales'),('Finance'),('Support');
INSERT INTO dbo.Admins(Username,[Password]) VALUES ('admin','admin123');
INSERT INTO dbo.Employees(FullName, Email, [Password], DepartmentId, Role, Salary, HireDate) VALUES
('Aarav Mehta','aarav@example.com','pass123',2,'Software Engineer',750000,'2023-06-01'),
('Priya Sharma','priya@example.com','pass123',1,'HR Executive',500000,'2022-12-15'),
('Rahul Verma','rahul@example.com','pass123',3,'Sales Associate',420000,'2024-03-10'),
('Neha Patel','neha@example.com','pass123',4,'Accountant',600000,'2021-09-01'),
('Vikram Singh','vikram@example.com','pass123',5,'Support Engineer',380000,'2024-01-12');
GO

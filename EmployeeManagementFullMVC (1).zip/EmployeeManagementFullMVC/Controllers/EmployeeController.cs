using System.Linq; using System.Web.Mvc; using System.Data.Entity; using EmployeeManagementFullMVC.Models;
namespace EmployeeManagementFullMVC.Controllers{
public class EmployeeController:Controller{
  private readonly EmployeeDbContext db=new EmployeeDbContext();
  public ActionResult Login()=>View();
  [HttpPost] public ActionResult Login(string email,string password){ var emp=db.Employees.FirstOrDefault(e=>e.Email==email && e.Password==password); if(emp!=null){ Session["EmployeeId"]=emp.EmployeeId; return RedirectToAction("Dashboard"); } ViewBag.Message="Invalid email or password."; return View(); }
  public ActionResult Dashboard(){ if(Session["EmployeeId"]==null) return RedirectToAction("Login"); int id=(int)Session["EmployeeId"]; var emp=db.Employees.Include(e=>e.Department).FirstOrDefault(e=>e.EmployeeId==id); return View(emp); }
  public ActionResult EditProfile(){ if(Session["EmployeeId"]==null) return RedirectToAction("Login"); int id=(int)Session["EmployeeId"]; var emp=db.Employees.Find(id); ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName", emp.DepartmentId); return View(emp); }
  [HttpPost] public ActionResult EditProfile(Employee e){ if(Session["EmployeeId"]==null) return RedirectToAction("Login"); if(ModelState.IsValid){ var x=db.Employees.Find(e.EmployeeId); if(x!=null){ x.FullName=e.FullName; x.Password=e.Password; x.DepartmentId=e.DepartmentId; x.Role=e.Role; x.Salary=e.Salary; x.HireDate=e.HireDate; db.SaveChanges(); } return RedirectToAction("Dashboard"); } ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName", e.DepartmentId); return View(e); }
  public ActionResult Logout(){ Session.Clear(); return RedirectToAction("Login"); }
}}

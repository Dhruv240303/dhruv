using System.Linq; using System.Web.Mvc; using EmployeeManagementFullMVC.Models;
namespace EmployeeManagementFullMVC.Controllers{
public class AdminController:Controller{
  private readonly EmployeeDbContext db=new EmployeeDbContext();
  public ActionResult Login()=>View();
  [HttpPost] public ActionResult Login(string username,string password){
    var admin=db.Admins.FirstOrDefault(a=>a.Username==username && a.Password==password);
    if(admin!=null){ Session["AdminId"]=admin.AdminId; return RedirectToAction("Dashboard"); }
    ViewBag.Message="Invalid admin credentials."; return View();
  }
  public ActionResult Dashboard(){ if(Session["AdminId"]==null) return RedirectToAction("Login");
    ViewBag.EmpCount=db.Employees.Count(); ViewBag.DeptCount=db.Departments.Count();
    var latest=db.Employees.OrderByDescending(e=>e.EmployeeId).Take(10).ToList(); return View(latest); }
  public ActionResult Logout(){ Session.Clear(); return RedirectToAction("Login"); }
}}

using System.Linq; using System.Web.Mvc; using EmployeeManagementFullMVC.Models;
namespace EmployeeManagementFullMVC.Controllers{
public class DepartmentsController:Controller{
  private readonly EmployeeDbContext db=new EmployeeDbContext();
  bool IsAdmin()=>Session["AdminId"]!=null;
  public ActionResult Index(){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Departments.OrderBy(d=>d.DepartmentName).ToList()); }
  public ActionResult Create(){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(); }
  [HttpPost] public ActionResult Create(Department d){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); if(ModelState.IsValid){ db.Departments.Add(d); db.SaveChanges(); return RedirectToAction("Index"); } return View(d); }
  public ActionResult Edit(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Departments.Find(id)); }
  [HttpPost] public ActionResult Edit(Department d){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); if(ModelState.IsValid){ var e=db.Departments.Find(d.DepartmentId); if(e!=null){ e.DepartmentName=d.DepartmentName; db.SaveChanges(); } return RedirectToAction("Index"); } return View(d); }
  public ActionResult Delete(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Departments.Find(id)); }
  [HttpPost, ActionName("Delete")] public ActionResult DeleteConfirmed(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); var d=db.Departments.Find(id); if(d!=null){ db.Departments.Remove(d); db.SaveChanges(); } return RedirectToAction("Index"); }
}}

using System.Data.Entity; using System.Linq; using System.Web.Mvc; using EmployeeManagementFullMVC.Models;
namespace EmployeeManagementFullMVC.Controllers{
public class EmployeesController:Controller{
  private readonly EmployeeDbContext db=new EmployeeDbContext();
  bool IsAdmin()=>Session["AdminId"]!=null;
  public ActionResult Index(){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Employees.Include(e=>e.Department).OrderBy(e=>e.EmployeeId).ToList()); }
  public ActionResult Details(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Employees.Include(e=>e.Department).FirstOrDefault(e=>e.EmployeeId==id)); }
  public ActionResult Create(){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName"); return View(); }
  [HttpPost] public ActionResult Create(Employee e){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); if(ModelState.IsValid){ db.Employees.Add(e); db.SaveChanges(); return RedirectToAction("Index"); } ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName",e.DepartmentId); return View(e); }
  public ActionResult Edit(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); var e=db.Employees.Find(id); ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName",e?.DepartmentId); return View(e); }
  [HttpPost] public ActionResult Edit(Employee e){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); if(ModelState.IsValid){ var x=db.Employees.Find(e.EmployeeId); if(x!=null){ x.FullName=e.FullName; x.Email=e.Email; x.Password=e.Password; x.DepartmentId=e.DepartmentId; x.Role=e.Role; x.Salary=e.Salary; x.HireDate=e.HireDate; db.SaveChanges(); } return RedirectToAction("Index"); } ViewBag.Departments=new SelectList(db.Departments,"DepartmentId","DepartmentName",e.DepartmentId); return View(e); }
  public ActionResult Delete(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); return View(db.Employees.Include(d=>d.Department).FirstOrDefault(e=>e.EmployeeId==id)); }
  [HttpPost, ActionName("Delete")] public ActionResult DeleteConfirmed(int id){ if(!IsAdmin()) return RedirectToAction("Login","Admin"); var e=db.Employees.Find(id); if(e!=null){ db.Employees.Remove(e); db.SaveChanges(); } return RedirectToAction("Index"); }
}}
